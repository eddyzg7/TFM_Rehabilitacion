#! /usr/bin/env python3

from json.tool import main
from multiprocessing.connection import wait
import random
from re import X 
import sys
import copy
from traceback import print_tb
from turtle import home
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from ast import Or, Return
import cv2
from matplotlib.image import imread
import numpy as np
from calibracion import *
from std_msgs.msg import Int8
from std_msgs.msg import String


def detector_aruco(frame, matrix, dist, id, posfin, tipo): #Crear lista y hablar con tomas
    
    #inicializar ArUco
    parametros =cv2.aruco.DetectorParameters_create()

    #Cargar diccionario
    diccionario = cv2.aruco.Dictionary_get(cv2.aruco.DICT_5X5_100)
    
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    #Detectamos Marcadores Implementando Distorsion 
    esquinas, ids, candidatos_malos = cv2.aruco.detectMarkers(gray, diccionario, parameters = parametros, cameraMatrix = matrix, distCoeff = dist)

    #Si encontramos marcadores
    if np.all(ids !=None):
        Arucos = [[None] * 3 for i in range(len(ids))]
        for i in range (0, len(ids)): #itera marcadores
            #posiciones respecto a los marcadores rotacion traslacion
            rvec, tvec, markerPoints = cv2.aruco.estimatePoseSingleMarkers(esquinas[i],0.02, matrix, dist)

            #corregir error de numpy
            (rvec -tvec).any()

            #dibujar cuadrado alrededor del marcador
            cv2.aruco.drawDetectedMarkers( frame, esquinas)

            #dibujar ejes
            cv2.aruco.drawAxis(frame , matrix, dist, rvec, tvec, 0.01)

            #extraer cordenadas X e Y del centro del marcador
            c_x = (esquinas[i][0][0][0] + esquinas[i][0][1][0] + esquinas[i][0][2][0] + esquinas[i][0][3][0]) / 4
            c_y = (esquinas[i][0][0][1] + esquinas[i][0][1][1] + esquinas[i][0][2][1] + esquinas[i][0][3][1]) / 4

            #mostrar ID
            cv2.putText(frame, "id" + str(ids[i]), (int(c_x), int(c_y)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (50,255,250), 2 )

            #ectraemos puntos de coordenadas separadas
            c1 = (esquinas[i][0][0][0], esquinas[i][0][0][1])
            c2 = (esquinas[i][0][1][0], esquinas[i][0][1][1])
            c3 = (esquinas[i][0][2][0], esquinas[i][0][2][1])
            c4 = (esquinas[i][0][3][0], esquinas[i][0][3][1])

            v1, v2 = c1[0] , c1[1]
            v3, v4 = c2[0] , c2[1]
            v5, v6 = c3[0] , c3[1]
            v7, v8 = c4[0] , c4[1]

            h = 100 #Altura realidad virtual

            #dibujar cuadrado
            #cara inferior
            cv2.line(frame, ( int(v1),int(v2) ), ( int(v3),int(v4) ), (255,255,0), 3)
            cv2.line(frame, ( int(v5),int(v6) ), ( int(v7),int(v8) ), (255,255,0), 3)
            cv2.line(frame, ( int(v1),int(v2) ), ( int(v7),int(v8) ), (255,255,0), 3)
            cv2.line(frame, ( int(v3),int(v4) ), ( int(v5),int(v6) ), (255,255,0), 3)
            #cara superior
            cv2.line(frame, ( int(v1),int(v2 - h) ), ( int(v3),int(v4 - h) ), (255,255,0), 3)
            cv2.line(frame, ( int(v5),int(v6 - h) ), ( int(v7),int(v8 - h) ), (255,255,0), 3)
            cv2.line(frame, ( int(v1),int(v2 - h) ), ( int(v7),int(v8 - h) ), (255,255,0), 3)
            cv2.line(frame, ( int(v3),int(v4 - h) ), ( int(v5),int(v6 - h) ), (255,255,0), 3)
            #lados
            cv2.line(frame, ( int(v1),int(v2 - h) ), ( int(v1),int(v2) ), (255,255,0), 3)
            cv2.line(frame, ( int(v3),int(v4 - h) ), ( int(v3),int(v4) ), (255,255,0), 3)
            cv2.line(frame, ( int(v5),int(v6 - h) ), ( int(v5),int(v6) ), (255,255,0), 3)
            cv2.line(frame, ( int(v7),int(v8 - h) ), ( int(v7),int(v8) ), (255,255,0), 3)
            

            Arucos[i][0] = int(ids[i][0])
            Arucos[i][1] = c_x
            Arucos[i][2] = c_y
    
        cv2.imwrite("/home/eddy/catkin_ws/src/mov_rehab/Img_ArUcos/Arucos_Detectados_"+str(ids[i])+".jpg",frame)
    else:
            ver = -1
            cv2.imwrite("/home/eddy/catkin_ws/src/mov_rehab/Img_ArUcos/Error.jpg",frame)
            return ver   

    #Ordenamos
    Arucos.sort()

    if tipo == 0 :
        return Arucos
    elif tipo == 1:
        #Creamos la division de los cuadrantes
        limX = 1280 / 3
        limY = 960 / 3
        #print("---")
        #print(Arucos)
        
        for i in range (0,3,1):
            if Arucos[i][0] == id:
                indice = i

        X = Arucos[indice][1]
        Y = Arucos[indice][2]

        if posfin == 1: #Cuadrante 1i
            if X < 1.5*limX and Y < limY : 
                ver = 0
            else:
                ver = 1
            return ver
        elif posfin == 2: #Cuadrante 2i
            if X < 1.5*limX and (Y > limY and Y < 2*limY): 
                ver = 0
            else:
                ver = 1
            return ver
        elif posfin == 3: #Cuadrante 3i
            if X < 1.5*limX and Y > 2*limY : 
                ver = 0
            else:
                ver = 1
            return ver
       
def Home():
    #HOME 
    joint_goal = group.get_current_joint_values()
    joint_goal[0] = PI/2
    joint_goal[1] = -PI/2
    joint_goal[2] = 0
    joint_goal[3] = -PI/2
    joint_goal[4] = -PI/2 
    joint_goal[5] = 0 

    group.set_joint_value_target(joint_goal)
    plan = group.go()

    group.stop()
    rospy.sleep(Tiempo_Inicial)

def Foto():
    #TOMAR FOTO
    joint_goal = group.get_current_joint_values()
    joint_goal[0] = PI/2
    joint_goal[1] = -90*PI/180
    joint_goal[2] = 45*PI/180
    joint_goal[3] = -45*PI/180
    joint_goal[4] = -PI/2 
    joint_goal[5] = 0

    group.set_joint_value_target(joint_goal)
    plan = group.go()

    group.stop()
    rospy.sleep(Tiempo_Inicial)

def posicion1():
    joint_goal = group.get_current_joint_values()
    joint_goal[0] = 113.27*PI/180
    joint_goal[1] = -44.53*PI/180
    joint_goal[2] = 121.09*PI/180
    joint_goal[3] = -167.36*PI/180
    joint_goal[4] = -89.28*PI/180 
    joint_goal[5] = 0

    group.set_joint_value_target(joint_goal)
    plan = group.go()

    group.stop()
    rospy.sleep(Tiempo_Inicial)

def posicion2():
    joint_goal = group.get_current_joint_values()
    joint_goal[0] = 107.76*PI/180
    joint_goal[1] = -38.23*PI/180
    joint_goal[2] = 99.72*PI/180
    joint_goal[3] = -152.21*PI/180
    joint_goal[4] = -84.75*PI/180
    joint_goal[5] = 0*PI/180

    group.set_joint_value_target(joint_goal)
    plan = group.go()

    group.stop()
    rospy.sleep(Tiempo_Inicial)

def posicion3():
    joint_goal = group.get_current_joint_values()
    joint_goal[0] = 105.54*PI/180
    joint_goal[1] = -27.51*PI/180
    joint_goal[2] = 71.23*PI/180
    joint_goal[3] = -133.48*PI/180
    joint_goal[4] = -88.10*PI/180
    joint_goal[5] = 0 

    group.set_joint_value_target(joint_goal)
    plan = group.go()

    group.stop()
    rospy.sleep(Tiempo_Inicial)

def Posicion1F():
    joint_goal = group.get_current_joint_values()
    joint_goal[0] = 50.72*PI/180
    joint_goal[1] = -47.55*PI/180
    joint_goal[2] = 143.27*PI/180
    joint_goal[3] = -183.98*PI/180
    joint_goal[4] = -87.36*PI/180
    joint_goal[5] = 0*PI/180

    group.set_joint_value_target(joint_goal)
    plan = group.go()

    group.stop()
    rospy.sleep(Tiempo_Inicial)

def Posicion2F():
    joint_goal = group.get_current_joint_values()
    joint_goal[0] = 63.17*PI/180
    joint_goal[1] = -44.75*PI/180
    joint_goal[2] = 113.21*PI/180
    joint_goal[3] = -153.83*PI/180
    joint_goal[4] = -89*PI/180
    joint_goal[5] = 0*PI/180

    group.set_joint_value_target(joint_goal)
    plan = group.go()

    group.stop()
    rospy.sleep(Tiempo_Inicial)

def Posicion3F():
    joint_goal = group.get_current_joint_values()
    joint_goal[0] = 69.89*PI/180
    joint_goal[1] = -32.56*PI/180
    joint_goal[2] = 82.72*PI/180
    joint_goal[3] = -138.62*PI/180
    joint_goal[4] = -88.92*PI/180
    joint_goal[5] = 0*PI/180

    group.set_joint_value_target(joint_goal)
    plan = group.go()

    group.stop()
    rospy.sleep(Tiempo_Inicial)

def Punto_Intermedio():
    joint_goal = group.get_current_joint_values()
    joint_goal[0] = 90*PI/180
    joint_goal[1] = -58*PI/180
    joint_goal[2] = 115*PI/180
    joint_goal[3] = -148*PI/180
    joint_goal[4] = -88*PI/180
    joint_goal[5] = 0*PI/180

    group.set_joint_value_target(joint_goal)
    plan = group.go()

    group.stop()
    rospy.sleep(Tiempo_Inicial)

def talker(accion):
    #rospy.loginfo(accion)
    pub.publish(accion) 

def ROS_MOBILE(mensaje):
    pub1.publish(mensaje) 

def Ejercicio1():
    # POSICION INICIAL
    joint_goal = group.get_current_joint_values()
    joint_goal[0] = PI/2
    joint_goal[1] = PI/6
    joint_goal[2] = -2*PI/3
    joint_goal[3] = -PI/2
    joint_goal[4] = -PI/2
    joint_goal[5] = 0  

    group.go(joint_goal, wait=True)
    group.stop()
    rospy.sleep(Tiempo_Ejercicio) 

    for i in range(0,Repet,1): #Subida
        
        #Manguito Rotador
        joint_goal = group.get_current_joint_values()
        joint_goal[5] = -PI
        
        group.go(joint_goal, wait=True)
        group.stop()
        rospy.sleep(Tiempo_Ejercicio)

        joint_goal = group.get_current_joint_values()
        joint_goal[5] = 0

        group.go(joint_goal, wait=True)
        group.stop()
        rospy.sleep(Tiempo_Ejercicio)

        #Elevacion Hombro
        joint_goal = group.get_current_joint_values()
        joint_goal[1] = joint_goal[1] - PI/6
        joint_goal[2] = joint_goal[2] + PI/6
 

        group.go(joint_goal, wait=True)
        group.stop()
        rospy.sleep(Tiempo_Ejercicio)

    for i in range(0,Repet,1): #Bajada
        
        #Manguito Rotador
        joint_goal = group.get_current_joint_values()
        joint_goal[5] = -PI 
        
        group.go(joint_goal, wait=True)
        group.stop()
        rospy.sleep(Tiempo_Ejercicio)

        joint_goal = group.get_current_joint_values()
        joint_goal[5] = 0

        group.go(joint_goal, wait=True)
        group.stop()
        rospy.sleep(Tiempo_Ejercicio)

        #Bajada de Hombro
        joint_goal = group.get_current_joint_values()
        joint_goal[1] = joint_goal[1] + PI/6
        joint_goal[2] = joint_goal[2] - PI/6 

        group.go(joint_goal, wait=True)
        group.stop()
        rospy.sleep(Tiempo_Ejercicio)
    
    Home()

def Ejercicio1_Techo():
    # POSICION INICIAL
    joint_goal = group.get_current_joint_values()
    joint_goal[0] = PI/2
    joint_goal[1] = -PI/2
    joint_goal[2] = PI/2
    joint_goal[3] = -PI/2
    joint_goal[4] = -PI/2
    joint_goal[5] = 0  

    group.go(joint_goal, wait=True)
    group.stop()
    rospy.sleep(Tiempo_Ejercicio)  


    #HOMBRO DERECHO

    for i in range(0,Repet,1): #Subida
        
        #Manguito Rotador
        joint_goal = group.get_current_joint_values()
        joint_goal[4] = -PI
        
        group.go(joint_goal, wait=True)
        group.stop()
        rospy.sleep(Tiempo_Ejercicio)

        joint_goal = group.get_current_joint_values()
        joint_goal[4] = -PI/2

        group.go(joint_goal, wait=True)
        group.stop()
        rospy.sleep(Tiempo_Ejercicio)

        #Elevacion Hombro
        joint_goal = group.get_current_joint_values()
        joint_goal[1] = joint_goal[1] + PI/4
        joint_goal[3] = joint_goal[3] - PI/4 

        group.go(joint_goal, wait=True)
        group.stop()
        rospy.sleep(Tiempo_Ejercicio)


    for i in range(0,Repet,1): #Bajada
        
        #Manguito Rotador
        joint_goal = group.get_current_joint_values()
        joint_goal[4] = -PI 
        
        group.go(joint_goal, wait=True)
        group.stop()
        rospy.sleep(Tiempo_Ejercicio)

        joint_goal = group.get_current_joint_values()
        joint_goal[4] = -PI/2

        group.go(joint_goal, wait=True)
        group.stop()
        rospy.sleep(Tiempo_Ejercicio)

        #Bajada de Hombro
        joint_goal = group.get_current_joint_values()
        joint_goal[1] = joint_goal[1] - PI/4
        joint_goal[3] = joint_goal[3] + PI/4

        group.go(joint_goal, wait=True)
        group.stop()
        rospy.sleep(Tiempo_Ejercicio)
    
    Home()

def Ejercicio2(matrix, dist, img):

    #Nos indica a que pieza debemos ir
    Orden = detector_aruco(img, matrix, dist, id=0, posfin=0, tipo = 0)
    rospy.sleep(2)
    #print(Orden)

    for i in range(0,3,1): #Realizamos 3 veces porque son 3 piezas
        id = Orden[i][0]
        Xid = Orden[i][1]
        Yid = Orden[i][2]
        #Indicacion
        posfin = random.choice(posf)
        #ROS_MOBILE("Mover ID " + str(id) + " a " + str(posfin) + " i")

        if(id == 1):
            color = "AZUL"
        elif (id == 2):
            color = "VERDE"
        elif (id == 3):
            color = "NARANJA"

        print("Mover ID " + str(id) + " ("+color+")" + " a " + str(posfin) + " i")
        posf.pop(posf.index(posfin))
        #print(posf)
        rospy.sleep(10) #Tiene 5 segundos para mover la pieza

        #Verificar 

        #TOMAR FOTO
        Foto()
        cap = cv2.VideoCapture(2) #Numero de webcam 2, la 0 es la del ordenador
        leido, img2 = cap.read()
        cap.release()

        rospy.sleep(2)

        ver = detector_aruco(img2, matrix, dist, id, posfin, tipo = 1)

        if ver == 0:
            print("--------")
            print("CORRECTO")
            print("--------")
            print(" ")
        elif ver == 1:
            while(ver == 1):
                print("----------------------------------------------------")
                print("INCORRECTO")
                print("REGRESE LA PIEZA A SU SITIO Y ESPERE LA DEMOSTRACION")
                rospy.sleep(10) #5S
                if  Xid > 1.5*limX and Yid < limY : #Cuadrante 1d
                    posicion1()
                    rospy.sleep(1) 
                    talker(1)
                    Punto_Intermedio()
                    if posfin == 1:
                        Posicion1F()
                    elif posfin == 2:
                        Posicion2F()
                    elif posfin == 3:
                        Posicion3F()
                    rospy.sleep(1) 
                    Punto_Intermedio()
                    posicion1()
                    talker(0)
                elif Xid > 1.5*limX and (Yid > limY and Yid < 2*limY): #Cuadrante 2d
                    posicion2()
                    rospy.sleep(1) 
                    talker(1)
                    Punto_Intermedio()
                    if posfin == 1:
                        Posicion1F()
                    elif posfin == 2:
                        Posicion2F()
                    elif posfin == 3:
                        Posicion3F()
                    rospy.sleep(1) 
                    Punto_Intermedio()
                    posicion2()
                    talker(0)
                elif Xid > 1.5*limX and Yid > 2*limY : #Cuadrante 3d
                    posicion3()
                    rospy.sleep(1) 
                    talker(1)
                    Punto_Intermedio()
                    if posfin == 1:
                        Posicion1F()
                    elif posfin == 2:
                        Posicion2F()
                    elif posfin == 3:
                        Posicion3F()
                    rospy.sleep(1) 
                    Punto_Intermedio()
                    posicion3()
                    talker(0)
                Foto()
                print(" ")
                print("REPITA EL MOVIMIENTO")
                print(" ")
                rospy.sleep(10) 
                #TOMAR FOTO
                #Foto()
                cap = cv2.VideoCapture(2) #Numero de webcam 2, la 0 es la del ordenador
                leido, img2 = cap.read()
                cap.release()     
                ver = detector_aruco(img2, matrix, dist, id, posfin, tipo = 1)
            Home()
            print("CORRECTO")
            print("----------------------------------------------------")
            print(" ")
        elif ver == -1:
            print("---------------------------------")
            print("NO SE HA ENCONTRADO NINGUNA PIEZA")
            print("---------------------------------")
            print(" ")
            rospy.sleep(10) 
            break
    Home()
    


# ----------------------- INICIALIZAMOS LOS PARAMETROS DEL ROBOT ----------------------- #
# Inicializamos el modulo Moveit commander
moveit_commander.roscpp_initialize(sys.argv)
# Inicializamos el nodo y le ponemos un nombre
rospy.init_node('move_group_python_interface_tutorial', anonymous=True)
# Creamos un objeto tipo robot, lo cual es la interfaz al robot
robot = moveit_commander.RobotCommander()
# Creamos un objeto tipo PlanningSceneInterference, es la interfaz del mundo que rodea al robot
scene = moveit_commander.PlanningSceneInterface()
# Creamos un objeto tipo MoveGroupCommander, que es la interfaz del grupo que ponemos con las articulaciones
group = moveit_commander.MoveGroupCommander("manipulator")
# Definimos el topico y el mensaje que se utiliza para publicar
display_trajectory_publisher = rospy.Publisher(
    '/move_group/display_planned_path', moveit_msgs.msg.DisplayTrajectory, queue_size=1)

# ----------------------- PARAMETROS DE ARDUINO -------------------------------------- #
pub = rospy.Publisher('Electroiman', Int8 , queue_size=10)

# ----------------------- PARAMETROS DE ROS MOBILE ----------------------------------- #
pub1 = rospy.Publisher('log', String , queue_size=10)


# ----------------------- VARIABLES -------------------------------------------------- #
Repet = 3   #Repeticiones del ejercicio
PI = 3.1416 #PI
Tiempo_Inicial = 1  #Tiempo antes de que inicie la rehabilitacion
Tiempo_Ejercicio = 1 #Tiempo de ejercicio
cont = 0
posf = [1,2,3]
limX = 1280 / 3
limY = 960 / 3

Home()

# ----------------------- EJERCICIO 1 ----------------------- #

#Ejercicio1()
#Ejercicio1_Techo()

# ----------------------- EJERCICIO 2 ----------------------- #

#Electroiman apagado
talker(0)
#Realizamos la calibracion de la camara
calibracion = calibracion()
matrix , dist = calibracion.calibration_cam() 
#Obtenemos el orden de los ids que se van a mover
Foto()
cap = cv2.VideoCapture(2) #Numero de webcam 2, la 0 es la del ordenador
leido, img = cap.read()
cap.release()
#Ejecutamos el ejercicio
Ejercicio2(matrix, dist, img)

moveit_commander.roscpp_shutdown()  # Despues de la accion apagamos el modulo